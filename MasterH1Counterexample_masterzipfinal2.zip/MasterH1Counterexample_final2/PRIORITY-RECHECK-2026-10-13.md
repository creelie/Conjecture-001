# Priority recheck, 13 October 2026, 23:23 UTC

Question: before this work, had anyone answered the question of Adams, Freese, Nation and Schmid
(1997) or proved or refuted Hypothesis 1 of Adaricheva, Mata, Silberger and Zamojska-Dzienio
(DMTCS 28:2 (2026), doi:10.46298/dmtcs.16374)?

| Source | Search | Result |
|---|---|---|
| arXiv API | `abs:"maximal sublattice"`, `abs:"maximal sublattices"`, newest first | only arXiv:2507.22682 (Adaricheva et al.) |
| arXiv API | `all:semidistributive AND all:sublattice`, newest first | arXiv:2507.22682 and papers on other topics (left modularity, the affine Tamari lattice, E-bases, s-permutahedra) |
| Zenodo | `"maximal sublattices"`, newest first | only the author's two records: this release (doi:10.5281/zenodo.23353448) and the earlier one (doi:10.5281/zenodo.23343145), which left Hypothesis 1 open |

The full check of 22:55–23:16 UTC (arXiv, Zenodo, Semantic Scholar, OpenRefute, web, classical
literature) is `repository/PRIORITY-CHECK.md`. Nothing found answers the question before this work.
