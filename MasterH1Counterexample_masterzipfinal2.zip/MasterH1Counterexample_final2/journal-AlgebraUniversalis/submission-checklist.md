# Submission checklist: Algebra Universalis

Journal: *Algebra Universalis* (Springer Nature; universal algebra and lattice theory). Submission
through the journal's Springer Nature submission system (link on the journal page at
https://link.springer.com/journal/12). Papers over 40 pages are discouraged; this one has 8.

Files to upload:

1. `au-manuscript-final2.pdf`: the manuscript in the Springer Nature class `sn-jnl`
   (option `sn-mathphys-num`).
2. `au-manuscript-source-final2.zip`: `main.tex`, the class file, the bibliography style and the
   two PNG figures; it compiles with `pdflatex main.tex` (three runs).
3. `cover-letter.md`: paste into the cover-letter field.

Metadata to enter:

- Title: Maximal sublattices of finite semidistributive lattices: the complement need not be an
  interval
- Author: Deep Bhattacharjee (sole author, corresponding), ORCID 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar,
  Odisha 751030, India
- Keywords: maximal sublattice; semidistributive lattice; bounded lattice; interval; formal
  verification
- MSC 2020: 06B05 (primary), 06B25 (secondary)

Only the author can confirm:

- [ ] "No funding was received for this work." (stated in the Declarations)
- [ ] "The author has no competing interests to declare." (stated in the Declarations)
- [ ] postal address and telephone number, if the system asks for them
- [ ] suggested referees, if the system asks (people who work on maximal sublattices or
      semidistributive lattices and are not coauthors of the author)

Before submitting, optionally post the arXiv tarball (`preprint/…-arxiv-final2.tar.gz`) to
arXiv (math.RA); the journal does not require it.
